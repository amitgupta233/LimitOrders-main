package org.afob.limit;

import org.afob.execution.ExecutionClient;
import org.afob.model.Order;
import org.afob.prices.PriceListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class LimitOrderAgent implements PriceListener {
    private static final Logger LOG = LoggerFactory.getLogger(LimitOrderAgent.class);
    private List<Order> orderList = new CopyOnWriteArrayList<>();
    private ExecutionClient executionClient;
    public LimitOrderAgent(ExecutionClient executionClient) {
        this.executionClient = executionClient;
    }

    @Override
    public void priceTick(String productId, BigDecimal price) {
        LOG.info("Current market price of {} is {}", productId, price);
        orderList.forEach(
                order -> {
                    // trigger buy order when it comes down to LimitPrice
                    if(productId.equalsIgnoreCase(order.getProductId())
                        && price.compareTo(order.getLimitPrice()) <= 0
                        && order.getOrderType() == 'B') {
                        try {
                            LOG.info("Buy {} stocks of {} @ limit price {} as current market price is {}", order.getAmount(), order.getProductId(), order.getLimitPrice(), price);
                            executionClient.buy(order.getProductId(), order.getAmount());
                            orderList.remove(order);
                        } catch (ExecutionClient.ExecutionException e) {
                            LOG.error("ExecutionException occurred while calling executionClient buy", e);
                            throw new RuntimeException(e);
                        }
                    }

                    // trigger sell order when it goes up to LimitPrice
                    if(productId.equalsIgnoreCase(order.getProductId())
                            && price.compareTo(order.getLimitPrice()) >= 0
                            && order.getOrderType() == 'S') {
                        try {
                            LOG.info("Sell {} stocks of {} @ limit price {} as current market price is {}", order.getAmount(), order.getProductId(), order.getLimitPrice(), price);
                            executionClient.sell(order.getProductId(), order.getAmount());
                            orderList.remove(order);
                        } catch (ExecutionClient.ExecutionException e) {
                            LOG.error("ExecutionException occurred while calling executionClient sell", e);
                            throw new RuntimeException(e);
                        }
                    }
                }
        );
    }

    public void addOrder(Order order) {
        LOG.info("Placed order {}", order);
        orderList.add(order);
        LOG.info("Order added to the list {}", orderList);
    }

}
