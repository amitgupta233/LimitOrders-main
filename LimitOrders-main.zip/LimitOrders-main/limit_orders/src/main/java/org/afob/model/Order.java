package org.afob.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
//@Setter
@ToString
public class Order {
    private String productId; // "IBM"
    private int amount; // 1000
    private BigDecimal limitPrice; // 100.00
    private Character orderType; // 'B' or 'S'

    public Order(String productId, int amount, BigDecimal limitPrice, Character orderType) {
        if(productId.isBlank())
            throw new IllegalArgumentException("Product ID cannot be blank");
        if(amount <= 0)
            throw new IllegalArgumentException("Amount cannot be 0 or less");
        if(limitPrice.compareTo(BigDecimal.ZERO) <= 0)
            throw new IllegalArgumentException("Limit Price cannot be 0 or less");
        if(orderType != 'B' && orderType != 'S')
            throw new IllegalArgumentException("Order Type should be either 'B' or 'S'");
        this.productId = productId;
        this.amount = amount;
        this.limitPrice = limitPrice;
        this.orderType = orderType;
    }

    public void setProductId(String productId) {
        if(productId.isBlank())
            throw new IllegalArgumentException("Product ID cannot be blank");
        this.productId = productId;
    }

    public void setAmount(int amount) {
        if(amount <= 0)
            throw new IllegalArgumentException("Amount cannot be 0 or less");
        this.amount = amount;
    }

    public void setLimitPrice(BigDecimal limitPrice) {
        if(limitPrice.compareTo(BigDecimal.ZERO) <= 0)
            throw new IllegalArgumentException("Limit Price cannot be 0 or less");
        this.limitPrice = limitPrice;
    }

    public void setOrderType(Character orderType) {
        if(orderType != 'B' && orderType != 'S')
            throw new IllegalArgumentException("Order Type should be either 'B' or 'S'");
        this.orderType = orderType;
    }
}
