package org.afob.execution;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ExecutionClientImpl extends ExecutionClient {
    private static final Logger LOG
            = LoggerFactory.getLogger(ExecutionClientImpl.class);

    /**
     * Execute a buy order
     * @param productId - the product to buy
     * @param amount - the amount to buy
     * @throws ExecutionException
     */
    @Override
    public void buy(String productId, int amount) throws ExecutionException {
        if(productId.isBlank() && amount <= 0)
            throw new ExecutionException("failed to buy: environment error");
        LOG.info("Bought {} stocks of {}", amount, productId);

    }

    /**
     * Execute a sell order
     * @param productId - the product to sell
     * @param amount - the amount to sell
     * @throws ExecutionException
     */
    @Override
    public void sell(String productId, int amount) throws ExecutionException {
        if(productId.isBlank() && amount <= 0)
            throw new ExecutionException("failed to sell: environment error");
        LOG.info("Sold {} stocks of {}", amount, productId);
    }

}
