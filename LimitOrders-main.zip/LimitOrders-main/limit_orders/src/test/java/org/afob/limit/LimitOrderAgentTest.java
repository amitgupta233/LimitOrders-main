package org.afob.limit;

import org.afob.execution.ExecutionClient;
import org.afob.model.Order;
import org.junit.jupiter.api.*;
import org.mockito.Mockito;

import java.math.BigDecimal;
import java.util.stream.Stream;

public class LimitOrderAgentTest {
    private static final String PRODUCT_ID = "IBM";
    private LimitOrderAgent limitOrderAgentVerify;
//    private LimitOrderAgent limitOrderAgent;
    private ExecutionClient executionClientMock = Mockito.mock(ExecutionClient.class);
//    private ExecutionClient executionClient;

    @BeforeEach
    public void setup() {
//        executionClient = new ExecutionClient();
        limitOrderAgentVerify = new LimitOrderAgent(executionClientMock);
//        limitOrderAgent = new LimitOrderAgent(executionClient);
    }

    @Test
    @DisplayName("When ProductId is invalid then it should throw IllegalArgumentException")
    public void testIllegalArgException() {
        IllegalArgumentException exception = Assertions.assertThrows(IllegalArgumentException.class, () -> new Order("", 1000, BigDecimal.valueOf(100.00), 'B'));
        Assertions.assertEquals("Product ID cannot be blank", exception.getMessage());
    }

//    @Test
//    @DisplayName("Test ExecutionException when issue with buy or sell order")
//    public void testExecutionException() {
//        ExecutionClient.ExecutionException buyException = Assertions.assertThrows(ExecutionClient.ExecutionException.class, () -> executionClientMock.buy("", -1));
//        Assertions.assertEquals("failed to buy: environment error", buyException.getMessage());
//
//        ExecutionClient.ExecutionException sellException = Assertions.assertThrows(ExecutionClient.ExecutionException.class, () -> executionClientMock.sell("", -1));
//        Assertions.assertEquals("failed to sell: environment error", sellException.getMessage());
//    }

    @Test
    @DisplayName("Verify Buy and Sell is getting called")
    public void testToVerifyBuyAndSell() throws ExecutionClient.ExecutionException {
        // Add LimitOrderAgent with Mocked ExecutionClient
        createAddOrder(limitOrderAgentVerify);

        // Create Stream of Market Price
        Stream<BigDecimal> marketPriceStream = getMarketPriceStream();

        // Iterate over market price
        marketPriceStream.forEachOrdered((marketPrice) -> limitOrderAgentVerify.priceTick(PRODUCT_ID, marketPrice));

        Mockito.verify(executionClientMock, Mockito.times(1)).buy(Mockito.anyString(), Mockito.anyInt());
//        Mockito.verify(executionClientMock, Mockito.times(2)).sell(Mockito.anyString(), Mockito.anyInt());

    }

    @Test
    public void test() throws ExecutionClient.ExecutionException {
        // buy IBM at 99.99 or 100 but not on 100.001
        // Add LimitOrderAgent with Actual ExecutionClient to check the buy and sell is happening in real-time
        createAddOrder(limitOrderAgentVerify);
        // Create Stream of Market Price
        Stream<BigDecimal> marketPriceStream = Stream.of(BigDecimal.valueOf(100.001), BigDecimal.valueOf(99.99), BigDecimal.valueOf(100.25));

        // Iterate over market price
        marketPriceStream.forEach((marketPrice) -> limitOrderAgentVerify.priceTick(PRODUCT_ID, marketPrice));

        Mockito.verify(executionClientMock, Mockito.times(1)).buy(Mockito.anyString(), Mockito.anyInt());
    }

    @Test
    @DisplayName("Test PriceTick method which is executing LimitOrders")
    public void testPriceTick() {

        // Add LimitOrderAgent with Actual ExecutionClient to check the buy and sell is happening in real-time
        createAddOrder(limitOrderAgentVerify);

        // Create Stream of Market Price
        Stream<BigDecimal> marketPriceStream = getMarketPriceStream();

        // Iterate over market price
        marketPriceStream.forEachOrdered((marketPrice) -> limitOrderAgentVerify.priceTick(PRODUCT_ID, marketPrice));

    }

    private void createAddOrder(LimitOrderAgent orderAgent) {
        orderAgent.addOrder(new Order(PRODUCT_ID, 1000, BigDecimal.valueOf(100.00), 'B'));
//        orderAgent.addOrder(new Order(PRODUCT_ID, 1000, BigDecimal.valueOf(95.00), 'B'));
//        orderAgent.addOrder(new Order(PRODUCT_ID, 1000, BigDecimal.valueOf(105.00), 'S'));
//        orderAgent.addOrder(new Order(PRODUCT_ID, 1000, BigDecimal.valueOf(110.00), 'S'));
    }

    private Stream<BigDecimal> getMarketPriceStream() {
        return Stream.of(BigDecimal.valueOf(100.55), BigDecimal.valueOf(100.35), BigDecimal.valueOf(100.25),
                BigDecimal.valueOf(100.15), BigDecimal.valueOf(100.001), BigDecimal.valueOf(99.99), BigDecimal.valueOf(100.25),
                BigDecimal.valueOf(100.15), BigDecimal.valueOf(100.05), BigDecimal.valueOf(95.10), BigDecimal.valueOf(94.95),
                BigDecimal.valueOf(104.55), BigDecimal.valueOf(104.35), BigDecimal.valueOf(103.25), BigDecimal.valueOf(105.15),
                BigDecimal.valueOf(111.05));
    }
}